
# Number Guessing Game

This is a simple Number Guessing Game implemented in Java. The program generates a random number between 1 and 100, 
and the player tries to guess it. The program provides feedback on whether the guess is too high, too low, or correct.

## How to Run
1. Ensure you have Java installed on your system.
2. Compile the program using the following command:
   ```
   javac guess.java
   ```
3. Run the compiled program:
   ```
   java guess
   ```

## Sample Output
```
Welcome to the Number Guessing Game!
"Let's begin the game."
Enter your guess: 50
Your guess is too high. Try again.
Enter your guess: 25
Your guess is too low. Try again.
Enter your guess: 30
Congratulations! You guessed the number correctly in 3 attempts.
Great game! Thank you for playing.
```

## Features
- Generates a random number between 1 and 100.
- Provides feedback on whether the guess is too high or too low.
- Tracks the number of attempts taken to guess correctly.

Enjoy the game!
