
import java.util.Scanner;
import java.util.Random;
public class guess {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Random rand = new Random();
        int numberguess = rand.nextInt(100) + 1;
        int attempts = 0;
        boolean hasWon = false;
        
        System.out.println("Welcome to the Number Guessing Game!");
        System.out.println(""Let's begin the game."");
        
        while (!hasWon) {
            System.out.print("Enter your guess: ");
            int guess = input.nextInt();
            attempts++;
            
            if (numberguess == guess) {
                System.out.println("Congratulations! You guessed the number correctly in " + attempts + " attempts.");
                hasWon = true;
            } else if (guess > numberguess) {
                System.out.println("Your guess is too high. Try again.");
            } else {
                System.out.println("Your guess is too low. Try again.");
            }
        }
        
        System.out.println("Great game! Thank you for playing.");
    }
}
